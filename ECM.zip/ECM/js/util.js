


var temp=[]
var a=[];
var temp2=[];
var temp1=[]
var Array1=[1]
var densityArray=[2, 4, 8, 12] 
var totaldensity=[]
var regionList=[0.56,0.71,0.86, 0.9,0.95]
var tempArray=[]
var result=[]
var oneTrial={}
var subjectId;
var repeat=20
var ind=299
var region=[]
var gg=[]
var correct1;
var lesser1;

console.log("本次实验共需："+(densityArray.length*regionList.length*repeat)+"次")
var totaltimess=densityArray.length*regionList.length*repeat;
 //alert(totaltimess)
var times=0
var t=0
var t2=0


function CC1(){
	for(var i=0;i<4;i++)
	{
		
		for(var k=t2;k<(t2+5);k++)
		{
		 
		a[k]={dx:densityArray[i],dy:regionList[(k-5*t)]}
		}//5,6,7,8,9=0,1,2,3,4   10,11,12,13,14=0,1,2,3,4
		t=t+1;
	    t2=t2+5;
		
	}
	  temp2=a;
	  for(var p=0;p<14;p++)
	  {a=a.concat(temp2)}	
	
	  for(var k=0,len=a.length;k<len;k++)
	  {
					var j=Math.floor(Math.random()*a.length)
				    temp[k]=a[j]	
					a.splice(j,1)
		}
	temp1=temp;
	
	
	}
	CC1();

function createECM(){
	oneTrial={};

	times=times+1;
	var startTime = new Date().getTime();
    var scale = 6/24;
    var width = 960,
        height = 400;
	var colors=["#FFFFFF","#FFFFFF"];
    var colorScale = d3.scale.linear()
        .domain([50, 0]).range(colors);
   
   var baoli=[];
   for(var r=0;r<32;r++)
   { baoli[r]=r
	   }



    var projection = d3.geo.mercator()
        .center([107, 38])
        .scale(500)
        .translate([width / 2, height / 2]);

    var path = d3.geo.path()
        .projection(projection);
		
	var color1 = d3.scale.category20();
		
    d3.json("data/china_provinces_remove2.json",
        function (data) {
            var provinces = data.features;
            var sel = d3.select("#ECM").append("svg")
                .attr("width", width)
                .attr("height", height)
				.attr("text-align","center")
				.attr('id','ECM');
            var outline = sel.append("g");
            var upd = outline.selectAll('path').data(provinces);
            var denter = upd.enter();
			
			
			
            //显示地图边框
            denter.append("path")
                .attr("stroke-width", 1)//TODO
                .attr("fill",'#FFFFFF')
                .attr("stroke", function (d) {
                    return "#000000";
                })
                .attr("d", path);
				
			
				var flu=temp1[ind].dy
				
				
				var regionDensity=temp1[ind].dx
				temp1.splice(ind,1)
				ind=ind-1;
				
			
			var correct=0;
			var lesser=0;
				function selected(){ 
			            correct=parseInt(Math.random()*regionDensity)
						 lesser=parseInt(Math.random()*regionDensity)
						if(correct==lesser)
						{selected();}
					}//选中最大值所在顺序
					
              var indexOfProv = parseInt(Math.random()*32);///最大值所在省份
			  var shunxu=[];
			   
			  //console.log("测试省份:"+provinces[indexOfProv].id+":"+(correct1+1))
			  oneTrial.expPro=provinces[indexOfProv].id
			  oneTrial.expNum=correct+1
			 
			  
            for (var i = 0; i < provinces.length; i++) {
                var pathOneProv = path(provinces[i]);
                var bbox = Snap.path.getBBox(pathOneProv);
                //样例数据
				var dd=[];
		
			   if(indexOfProv==i)
			   {
				    selected();
					oneTrial.expNum=correct+1;
					correct1=correct;
					 lesser1=lesser;
					 console.log("测试省份:"+provinces[indexOfProv].id+":"+(correct1+1))
                   /* sel.append("rect")//这里是黑框
                       .attr("x", -10)//TODO sort
                        .attr("width", bbox.width+20)
                        .attr("y", -10)
                        .attr("height", bbox.height + 20)
                        .attr("stroke", "#000000")
                        .attr("stroke-width", 2)
                        //.attr("fill", red)//填充颜色
                        .attr("fill-opacity", 0)
                        .attr("transform", "translate(" + bbox.x + "," + bbox.y + ")");*/
				for(var h=0;h<regionDensity;h++){
				   
				   
					region[h]=(/*tempArray[regionIndex]*/h/(regionDensity));
					if(h==correct)
					var g={dx:region[h],dy:100}
					
					else if(h==lesser)
					{var g={dx:region[h],dy:100*flu}}
					else
					{var g={dx:region[h],dy:Math.random()*100*flu}}
					
					gg[h]=g.dy
					dd[h]=g;
					
					}
					}

			  else
			  {
				  selected();
				  for(var h=0;h<regionDensity;h++){
				 region[h]=(h/(regionDensity));
					if(h==correct)
					var g={dx:region[h],dy:100}
					
					else if(h==lesser)
					{var g={dx:region[h],dy:100*flu}}
					else
					{var g={dx:region[h],dy:Math.random()*100*flu}}
					
					gg[h]=g.dy
					dd[h]=g;
					}
					}


                var x = d3.scale.linear().range([0+scale*bbox.width, bbox.width-scale*bbox.width]).domain([0,1]);
                var y = d3.scale.linear().range([0+scale*bbox.height, bbox.height-scale*bbox.height]).domain([100, 0]);
                
					         
                                 
				var area=d3.svg.area()	
						   .x(function(d) { return x(d.dx); })
                           .y0( bbox.height-scale*bbox.height)
                           .y1(function(d) { return y(d.dy); });						 
                                
  

 
				 var bar=sel.append("g")
                            .attr("transform", "translate(" + bbox.x +
                    "," + bbox.y + ")")
					//.attr('class','area')
			     var pp=bar.append("path")
                    .datum(dd)
                    .attr("class", "area2")
					.attr('stroke-width',0)
					.style("fill", "#191970")
                    .style("fill", "#feb24c")
					.attr('opacity',1)
                    .attr("d", function(d, i ){
                        return area(d);
                    })
                    
	            var xAxis=d3.svg.axis()  
                            .scale(x)  
                            .ticks(regionDensity)
			//.attr('stroke-width', 1.5)  
                            .tickFormat(d3.format("d"))  
                            .orient("bottom");  
  
               var yAxis=d3.svg.axis()  
                           .scale(y)
			               .ticks(1)  
                           .orient("left");  
  
  

		
		       var tempBarGShadow = sel.append("g")
                                       .attr("id", "tempBarShadow" + provinces[i].id)
                                       .attr("width", bbox.width)
                                       .attr("height", bbox.height)
					                   .style("fill", "#191970")
                                       .attr("cursor", "pointer")
                                       .attr("transform", "translate(" + bbox.x + "," + (bbox.y-bbox.height+2*scale*bbox.height) + ")")
					//.attr("transform", "translate(" + bbox.x + "," + (bbox.y-2*scale*bbox.height) + ")")
					                   .attr("y",0)

          
		  
		  
		  
		  
	 for (var j = 0; j < regionDensity; j++) {
		                var down=bbox.height-(bbox.height-2*scale*bbox.height)*dd[j].dy/100;
					     
                        var Rect=tempBarGShadow.append("rect")
									   .datum(dd)/*TODO sort*/
									   Rect
									   .style("fill", "#FF0000")
                                      .attr("id", "tempbarshadowRectId" + j)
                                      .attr("x", function(){
										  var px=((bbox.width-2*scale*bbox.width)/ regionDensity)*0.5
										      px1=j * (bbox.width-2*scale*bbox.width) /regionDensity
											  return px1-px;})
                                      .attr("width", ((bbox.width-2*scale*bbox.width)/ regionDensity))
                                     
                                      
									  .attr("height", (bbox.height-2*scale*bbox.height)*dd[j].dy/100)
									  
                                      
									  
									 .style("fill", "#FF0000")
					                  .attr('opacity',0)
									  .attr('stroke-width',0)
									  .attr('stroke','yellow')
									  .attr('stroke-opacity',1)
                                      .attr("filter", "grayscale(100%)")
									  .attr('index',(j+1))
									  .style("z-index",999)
							          .attr("transform", "translate(" + (scale*bbox.width)+
                  "," + (scale*bbox.height+down) + ")")
					        
                            .attr("clip-path", "url(#clippath" + provinces[i].id + ")")
							
							
							 if(1)
			  {
				    var bbox1 = Snap.path.getBBox(path(provinces[indexOfProv]));
							  sel.append("rect")//这里是黑框
                       .attr("x", -10)//TODO sort
                        .attr("width", bbox1.width+20)
                        .attr("y", -10)
                        .attr("height", bbox1.height + 20)
                        .attr("stroke", "#000000")
                        .attr("stroke-width", 2)
                      //  .attr("fill", red)//填充颜色
                        .attr("fill-opacity", 0)
                        .attr("transform", "translate(" + bbox1.x + "," + bbox1.y + ")")
						.style("pointer-events","none")
			  }
							
						Rect.on("mousedown",function(){
		                        var indexx=(this.getAttribute('index'))
		
	                        	var filterId = function(ids){
                                return ids.substr(19);
                            };
                            //var indexx=parseInt((indexx+1)/10+1)
                            var clip = this.getAttribute("clip-path");
                            var selectedProv = clip.substring(13,clip.length-1);
							var endTime = new Date().getTime();
                            //console.log("选中位置:"+ selectedProv+":"+/*filterId(this.id)*/indexx);
							console.log( selectedProv+","+/*filterId(this.id)*/indexx);
							oneTrial.selPro=selectedProv;
							oneTrial.selNum=indexx;
							var judg=correct1+1;
							if(indexx==judg&&selectedProv==provinces[indexOfProv].id)
							{console.log("正确")
							oneTrial.Res='正确'}
							else{console.log("错误")
							oneTrial.Res='错误'}
			               				
		 
		$('#ECM').empty();
		                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
		
		
		  totalTime=(endTime-startTime)/1000;
		 //console.log("用时:"+totalTime+" 秒")
		 console.log(totalTime)
		 oneTrial.Time=totalTime;
		//console.log("数据密度:"+regionDensity)
		console.log(regionDensity)
		oneTrial.Dens=regionDensity;
		//console.log("最大值与次大值:"+flu)
		console.log(flu)
		oneTrial.Fluc=flu;
		//alert(oneTrial.bd)
		result.push(oneTrial)
		console.log("--------------------------------------------")
		
		if(times>=720)
		{     
			console.log("实验结束,谢谢参与！~")
			
			result=JSON.stringify(result)
			var blob = new Blob([result], {type: "text/plain;charset=utf-8"});
            saveAs(blob, "SaveResult.txt");}
			
		else
		{createECM();}
		
		})
		                     
	 }}
            

		});
}
