// JavaScript Document
function ColorIt(){
var a=d3.rgb(66,251,75);
var b=d3.rgb(2,100,7);
var linear1=d3.scale.linear()
              .domain([1,32])
			  .rang([0,1]);
			  

var Color=d3.interpolate(a,b)
var values=[];
for(var i=0;i<provinces.length;i++){
	var name=provinces[i].properties.name;
	var value=provinces[i].properties.childNum;
	values[name]=value;
	
	}
provinces.style('fill',function(d,i){
	var t=linear1(values[d.provinces[i].properties.name]);
	var color=Color(t);
	return color.toString();})
}


