// JavaScript Document
var t=0
var t2=0
var temp=[]
function CC(){
	var a=[];
	for(var i=0;i<6;i++){
		
		for(var k=t2;k<(t2+5);k++){
		a[k]={dx:densityArray[i],dy:regionList[(k-5*t)]}//5,6,7,8,9=0,1,2,3,4   10,11,12,13,14=0,1,2,3,4
		
		}
		 t=t+1;
		 t2=t2+5;
		}
	
	for(var i=0;i<30;i++){
	for(var k=0,len=a.length;k<len;k++)
				{
					var j=Math.floor(Math.random()*a.length)
				    temp[k]=a[j]	
					a.splice(j,1)
				}
			
	
	}
	
	
	}